[name     = 'Magnus Lie Hetland' ]
[email    = 'magnus@foo.bar'     ]
[language = 'python'             ]
