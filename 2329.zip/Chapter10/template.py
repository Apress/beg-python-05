[x = 2]
[y = 3]
The sum of [x] and [y] is [x + y].
