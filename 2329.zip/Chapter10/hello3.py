# hello3.py
def hello():
    print "Hello, world!"

# A test:
hello()
