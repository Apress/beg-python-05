class A:
    def hello(self):
        print "Hello, I'm A."

class B(A):
    def hello(self):
        print "Hello, I'm B."
