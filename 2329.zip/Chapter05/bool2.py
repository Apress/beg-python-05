if number <= 10 and number >= 1:
    print 'Great!'
else:
    print 'Wrong!'
