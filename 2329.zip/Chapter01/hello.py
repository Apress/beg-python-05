name = raw_input("What is your name? ")
print "Hello, " + name + "!"
raw_input("Press <enter>")