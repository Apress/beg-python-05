d = {}
d['name'] = 'Gumby'
d['age'] = 42
d
{'age': 42, 'name': 'Gumby'}
returned_value = d.clear()
d
{}
print returned_value
